//
//  ViewController.swift
//  FBLogin
//
//  Created by mac on 21/10/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import FBSDKLoginKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func clickOnLogin(_ sender: UIButton) {
        self.signInWithFacebook()
    }
    
}

//MARK:- Facebook Login.
extension ViewController {
    
    func signInWithFacebook() {
        //AccessToken.setCurrent(nil)
        AccessToken.current = nil
        let fetchUserInfoFromFaceBook = {() -> Void in
            let graphResquest = GraphRequest(graphPath: "me", parameters: ["fields": "id,first_name,last_name,email,gender,birthday,picture.width(480).height(480)"])
            
            _ = graphResquest.start { connection, result, error in
                let dictionary = result as! Dictionary<String, Any>
                
                //self.userObj = SocialLoginGetModel()
                
                if let picture = dictionary["picture"] as? [String:Any] ,
                    let imgData = picture["data"] as? [String:Any] ,
                    let imgUrl = imgData["url"] as? String {
                    //self.userObj.ProfileUrl = imgUrl
                    print("imgUrl :", imgUrl)
                }
                if let fname:String = dictionary["first_name"] as? String, let lname:String = dictionary["last_name"] as? String {
                    //self.userObj.FullName = fname + " " + lname
                    print("Name : ", fname + " " + lname)
                    
                }
                
                if let fname:String = dictionary["first_name"] as? String{
                    //self.userObj.FirstName = fname
                    print("Fname : ", fname)
                }
                if let lname:String = dictionary["last_name"] as? String{
                    //self.userObj.LastName = lname
                    print("Lname : ", lname)
                }
                if let email:String = dictionary["email"] as? String{
                    //self.userObj.Email = email
                    print("Email : ", email)
                }
                if let id:String = dictionary["id"] as? String{
                    //self.userObj.SocilaID = id
                    print("id : ", id)
                }
                //self.userObj.SocialType = SocialMediaType.facebook.rawValue
                //self.signIn()
            }
        }
        if AccessToken.current != nil {
            fetchUserInfoFromFaceBook()
        }else {
            let loginManager = LoginManager()
            loginManager.logIn(permissions: ["public_profile", "email", "user_friends"], from: self, handler: { (signInResult, error) in
                if error != nil {
                    print("Process error")
                }
                else if (signInResult?.isCancelled)! {
                    print("Cancelled")
                }
                else {
                    fetchUserInfoFromFaceBook()
                    print("logged in")
                }
            })
        }
    }
}
